#include <iostream>

using namespace std;
int m[10][10];

//menu
void menu();
//inicializa
void inicializa(int v);
//imprimir
void imprimir();
//asigna
void asignar(int i, int j, int valor);
//elimina
void eliminar(int i, int j, int valor);

int main(int argc, char** argv) {
	while(true){
		menu();

	}
	return 0;
}

void menu(){
	int menu,i,j,v;
	cout<<"Seleccione lo que desea realizar"<<endl;
	cout<<"1- Inicializar valores"<<endl;
	cout<<"2- Imprimir valores"<<endl;
	cout<<"3- Asignar valores"<<endl;
	cout<<"4- Eliminar valores"<<endl;
	cout<<"5- Salir"<<endl;
	cin>>menu;
	switch(menu){
		case 1:
			inicializa(-1);
			break;
		case 2:
			imprimir();
			break;
		case 3:
			cout<<"Ingrese i"<<endl;
			cin>>i;
			cout<<"Ingrese j"<<endl;
			cin>>j;
			cout<<"Ingrese el valor"<<endl;
			cin>>v;
			asignar(i,j,v);
			break;
		case 4:
			cout<<"Ingrese i"<<endl;
			cin>>i;
			cout<<"Ingrese j"<<endl;
			cin>>j;
			asignar(i,j,-1);
			break;
		case 5:
			exit(-1);
			break;
		default:
			cout<<"Ingrese un valor correcto"<<endl;
	}
}


void inicializa(int v){
	for(int i=0;i<10;i++){
		for(int j=0;j<10;j++){
		m[i][j]=v;
		}
	}
}

void imprimir(){
	for(int i=0;i<10;i++){
		cout<<"|";
		for(int j=0;j<10;j++){
			if(m[i][j]!=-1){
				cout<<m[i][j]<<"|";
			}else{
				cout<<" "<<"|";
			}
				
		}
		cout<<endl;
	}
}

void asignar(int i, int j, int valor){
	m[i][j]=valor;
}

void eliminar(int i, int j, int valor){
	m[i][j]=valor;
}
