#include <iostream>
#include "Churro.cpp"

using namespace std;

int main(int argc, char** argv) {
	
	Churro a;
	Churro b;
	a.setNombre("Zambos");
	a.setPrecio(29.50);
	a.imprime();

	
	b.setNombre("Doritos");
	b.imprime();
	return 0;
}
